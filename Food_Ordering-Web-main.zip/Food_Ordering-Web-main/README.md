### **Online Food Ordering-Web**
Online Food Ordering System Website using basic HTML , CSS and JavaScript. It also provides menu, restaurant services, details  and reservation form for the user.

### **Home page Screenshot**
![1-home-page](https://user-images.githubusercontent.com/83177745/174050641-fd4efa8d-8dae-4d69-981c-99d81e920a7f.jpg)
Find how the project looks in screenshots folder .

### **Technologies Used**
- HTML
- CSS
- Java Script


### **How to Use**
- Download  the files of this project.
- Copy the folder of this project in your folder.
- Open your web browser and check if you got the website running on your localhost.


### **Author**
**Mubashara Khan**

**- GitHub:**   https://github.com/mubasharaKhan

**- LinkedIn:**  https://www.linkedin.com/in/mubashara-khan-8161371b9
